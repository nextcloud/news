# Authors
* [Alessandro Cosentino](https://github.com/zimba12): <cosenal@gmail.com>
* [Bernhard Posselt](https://github.com/Raydiation): <dev@bernhard-posselt.com>

## Designers

* [Jan-Christoph Borchardt](https://github.com/jancborchardt): <hey@jancborchardt.net>
* [Raghu Nayyar](https://github.com/raghunayyar): <me@iraghu.com>
* [Bernhard Posselt](https://github.com/Raydiation): <dev@bernhard-posselt.com>


## Contributors

* [Robin Appelman](https://github.com/icewind1991): <icewind@owncloud.com>
* [Morris Jobke](https://github.com/kabum): <morris.jobke@gmail.com>
* [Lukas Reschke](https://github.com/LukasReschke): <lukas@statuscode.ch>
* [bluehaze](https://github.com/bluehaze)
* [Dave Hou Qingping](https://github.com/houqp): <dave2008713@gmail.com> 
* [David Kleuker](https://github.com/davidak): <info@davidak.de> 
* [bastei](https://github.com/bastei)
* [Peter Hedlund](https://github.com/phedlund): <support@peterandlinda.com>
* [benediktb](https://github.com/benediktb)
* [Maik Kulbe](https://github.com/mkzero)
* [s17t.net](https://github.com/s17t): <mail+github@s17t.net>
* [John Kristensen](https://github.com/jerrykan)
* [Lutz Schildt](https://github.com/lsmooth): <ls@lsmooth.de>
* [Christopher](https://github.com/Kondou-ger): <kondou@ts.unde.re>
* [Xemle](https://github.com/xemle): <xemle@phtagr.org>