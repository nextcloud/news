<?php $TRANSLATIONS = array(
"Settings" => "Instellings"
);
