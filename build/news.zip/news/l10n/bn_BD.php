<?php $TRANSLATIONS = array(
"News" => "সংবাদ",
"Address" => "ঠিকানা",
"Add" => "যোগ কর",
"Folder" => "ফোল্ডার",
"Starred" => "তারা চিহ্নিত",
"by" => "কর্তৃক",
"Download" => "ডাউনলোড",
"Import" => "আমদানি",
"Export" => "রপ্তানি"
);
