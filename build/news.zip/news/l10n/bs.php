<?php $TRANSLATIONS = array(
"News" => "Vijesti",
"Address" => "Adresa",
"Add" => "Dodaj",
"New folder" => "Nova fascikla",
"Folder" => "Fasikla",
"Starred" => "Označeno",
"Keep unread" => "Zadrži nepročitano",
"Collapse" => "Proširi",
"Delete folder" => "Izbriši fasciklu",
"Rename folder" => "Preimenuj fasciklu",
"Show only unread" => "Prikaži samo nepročitane"
);
