<?php $TRANSLATIONS = array(
"Address" => "Cyfeiriad",
"Add" => "Ychwanegu",
"Folder" => "Plygell",
"by" => "gan",
"Download" => "Llwytho i lawr",
"Import" => "Mewnforio",
"Export" => "Allforio"
);
