<?php $TRANSLATIONS = array(
"Address" => "عنوان",
"Add" => "أدخل",
"Folder" => "مجلد",
"by" => "من قبل",
"Download" => "تحميل",
"Import" => "إدخال",
"Export" => "تصدير"
);
